package fr.eni.auctionflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctionFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
